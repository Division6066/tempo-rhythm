## הגדרת מערכת תשלומים עם Polar (לתבנית Web)

### מה אנחנו בונים כאן
בפרויקט הזה יש Paywall (מודל תשלום) שמציג 3 תוכניות:
- **חינם**
- **חודשי**
- **שנתי**

כשלוחצים על תוכנית בתשלום, האפליקציה מבצעת Redirect ל-Polar Checkout דרך נתיב שרת ב-Next.js.

---

### 1) התקנת החבילה
בתבנית כבר הותקנה החבילה:
- `@polar-sh/nextjs`

אם מסיבה כלשהי היא לא מותקנת:

```bash
bun add @polar-sh/nextjs
```

---

### 2) יצירת מוצרים ב-Polar
1. היכנסו ל-Polar Dashboard.
2. צרו שני מוצרים (Products):
   - **תוכנית חודשית**
   - **תוכנית שנתית**
3. העתיקו את ה-**Product ID** לכל מוצר.

הערה: ה-Product ID הוא הערך שנעביר לפרמטר `products` בנתיב `/checkout`.

---

### 3) הגדרת משתני סביבה (Environment Variables)

#### משתני שרת (לא נחשפים לדפדפן)
הגדירו בקובץ `.env.local` (מומלץ) או בסביבת הפריסה (Vercel וכו'):

- `POLAR_ACCESS_TOKEN`
  - טוקן ארגוני (OAT) של Polar.
  - **אסור** לחשוף אותו בצד לקוח.

- `POLAR_SUCCESS_URL`
  - כתובת אליה Polar יפנה לאחר Checkout מוצלח.
  - מומלץ להגדיר כך:

```txt
POLAR_SUCCESS_URL=http://localhost:3000/success?checkout_id={CHECKOUT_ID}
```

> חשוב: `{CHECKOUT_ID}` מוחלף על ידי Polar ב-ID אמיתי, כדי שנוכל לאמת תשלום ולעדכן משתמש בעתיד.

#### משתני לקוח (נחשפים לדפדפן — לתצוגה בלבד)
הגדירו גם:

```txt
NEXT_PUBLIC_POLAR_MONTHLY_PRODUCT_ID=XXX
NEXT_PUBLIC_POLAR_YEARLY_PRODUCT_ID=YYY
```

---

### 4) נתיב Checkout בשרת (כבר מוכן בתבנית)
הנתיב נמצא כאן:
- `app/checkout/route.ts`

הוא משתמש ב-`Checkout()` של `@polar-sh/nextjs` ויוצר Checkout Session ב-Polar.

איך מפעילים אותו בפועל מהלקוח:
- הלקוח ניגש לכתובת:
  - `/checkout?products=<PRODUCT_ID>`

לדוגמה:
- `/checkout?products=prod_123...`

---

### 5) הפעלה/כיבוי של Paywall ותשלומים
הקובץ המרכזי שמנהל את הדגלים נמצא כאן:
- `config/appConfig.ts`

דגלים חשובים:
- `PAYWALL_ENABLED`
  - אם `true`: עמודים נעולים (למשל `page2` ו-`page3`) יציגו Paywall למשתמש חינמי.
  - אם `false`: לא יוצג Paywall, והעמודים יהיו פתוחים.

- `PAYMENT_SYSTEM_ENABLED`
  - אם `true`: לחיצה על המשך במודל תשלום תבצע Redirect ל-Polar Checkout.
  - אם `false`: יוצג מצב Preview (ללא תשלום אמיתי).

- `MOCK_PAYMENTS`
  - אם `true`: אפשר לדמות שדרוג למשתמש בתשלום (במקום Polar) לצורך בדיקות UI.

---

### 6) מה חסר עדיין כדי שזה יעבוד "כמו מוצר אמיתי"
כרגע התבנית מחברת **Checkout** בלבד.
כדי להפוך את זה למערכת תשלומים מלאה, צריך:

- **Webhook** מ-Polar לאחר תשלום מוצלח
- אימות התשלום בצד שרת
- עדכון `userType` של המשתמש ב-Convex ל-`paid`

הנקודות הללו תלויות בארכיטקטורה שתרצו:
- האם אתם רוצים Subscription אמיתי?
- האם יש ניסיון חינם?
- האם יש אפשרות ביטול/חידוש דרך פורטל לקוח?

למידע על API ושיקולי אבטחה:
- [Polar API Overview](https://polar.sh/docs/api-reference/introduction)

---

### 7) בדיקות מהירות (Sanity Check)
1. הגדירו את משתני הסביבה.
2. ודאו ש-`PAYWALL_ENABLED=true`.
3. ודאו ש-`PAYMENT_SYSTEM_ENABLED=true`.
4. התחברו לאפליקציה.
5. כנסו ל-`/page2` או `page3`.
6. בחרו חודשי/שנתי ולחצו "המשך".

אם הכול תקין — אתם תועברו ל-Polar Checkout.
